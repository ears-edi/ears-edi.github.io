import time
import pycom
import machine
import tiny_http
from network import WLAN

SSID = "VM4910285"
PASS = "s3rMbmq3yrwy"

pycom.heartbeat(False)

wlan = WLAN(mode=WLAN.STA)
print("MAIN: WLAN Initialised")

nets = wlan.scan()
for net in nets:
    if net.ssid == SSID:
        wlan.connect(net.ssid, auth=(net.sec, PASS), timeout=5000)
        while not wlan.isconnected():
            machine.idle()
        print("Connected to network")

# Example tiny_http usage
# print(tiny_http.get_request("192.168.0.10", 5000, "/"))



adc = machine.ADC()
read_pin = adc.channel(pin="P16")

while True:
    val = read_pin()
    endpoint = "/putldrdata/{}".format(val)
    resp = tiny_http.get_request("192.168.0.10", 5000, endpoint)
    if resp != b"OK":
        print("oh no")
        break

    time.sleep(1)
